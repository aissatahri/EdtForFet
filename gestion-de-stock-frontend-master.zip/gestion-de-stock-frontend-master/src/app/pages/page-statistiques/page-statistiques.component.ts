import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-statistiques',
  templateUrl: './page-statistiques.component.html',
  styleUrls: ['./page-statistiques.component.scss']
})
export class PageStatistiquesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-mvtstk',
  templateUrl: './page-mvtstk.component.html',
  styleUrls: ['./page-mvtstk.component.scss']
})
export class PageMvtstkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

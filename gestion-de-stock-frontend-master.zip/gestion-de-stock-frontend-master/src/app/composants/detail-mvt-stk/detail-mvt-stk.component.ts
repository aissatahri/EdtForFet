import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-mvt-stk',
  templateUrl: './detail-mvt-stk.component.html',
  styleUrls: ['./detail-mvt-stk.component.scss']
})
export class DetailMvtStkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

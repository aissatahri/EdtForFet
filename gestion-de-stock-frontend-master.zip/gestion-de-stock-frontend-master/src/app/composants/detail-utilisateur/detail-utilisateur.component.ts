import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-utilisateur',
  templateUrl: './detail-utilisateur.component.html',
  styleUrls: ['./detail-utilisateur.component.scss']
})
export class DetailUtilisateurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

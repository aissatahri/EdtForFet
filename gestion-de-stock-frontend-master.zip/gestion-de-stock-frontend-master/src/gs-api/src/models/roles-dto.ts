/* tslint:disable */
export interface RolesDto {
  id?: number;
  roleName?: string;
}

/* tslint:disable */
export interface ChangerMotDePasseUtilisateurDto {
  id?: number;
  motDePasse?: string;
  confirmMotDePasse?: string;
}

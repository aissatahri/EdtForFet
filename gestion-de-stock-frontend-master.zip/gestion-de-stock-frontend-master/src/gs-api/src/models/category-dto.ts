/* tslint:disable */
export interface CategoryDto {
  id?: number;
  code?: string;
  designation?: string;
  idEntreprise?: number;
}

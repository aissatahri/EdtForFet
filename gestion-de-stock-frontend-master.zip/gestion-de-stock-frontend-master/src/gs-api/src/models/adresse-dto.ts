/* tslint:disable */
export interface AdresseDto {
  adresse1?: string;
  adresse2?: string;
  ville?: string;
  codePostale?: string;
  pays?: string;
}

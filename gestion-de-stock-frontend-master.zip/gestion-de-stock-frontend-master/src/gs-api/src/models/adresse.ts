/* tslint:disable */
export interface Adresse {
  adresse1?: string;
  adresse2?: string;
  ville?: string;
  codePostale?: string;
  pays?: string;
}

/* tslint:disable */
export interface AuthenticationRequest {
  login?: string;
  password?: string;
}

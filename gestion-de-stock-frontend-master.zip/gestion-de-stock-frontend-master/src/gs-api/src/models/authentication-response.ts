/* tslint:disable */
export interface AuthenticationResponse {
  accessToken?: string;
}
